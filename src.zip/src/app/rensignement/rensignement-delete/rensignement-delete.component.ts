import { Component, OnInit } from '@angular/core';
import {ReunionService} from '../../service/reunion.service' ;
import { Reunion } from '../../Model/reunion';
import { FormsModule, ReactiveFormsModule , FormGroup, FormControl}  from '@angular/forms';

@Component({
  selector: 'app-rensignement-delete',
  templateUrl: './rensignement-delete.component.html',
  styleUrls: ['./rensignement-delete.component.css']
})
export class RensignementDeleteComponent implements OnInit {
 r: Reunion[] = new Array();
reunion : Reunion ;

  constructor(private reunionservice: ReunionService) { }

  ngOnInit() {this.getAll (); }
 private getAll() {

  this.reunionservice.getAll().subscribe(data => {
this.r=data ;
      console.log(this.r);
    }, ex => {
      console.log(ex);
    });

  }
  private modifier(reunion : Reunion) {
    this.reunionservice.update(reunion).subscribe( data => {

     if (data.success) {} else {}
    }, ex => {console.log(ex);
    });
  }


}
