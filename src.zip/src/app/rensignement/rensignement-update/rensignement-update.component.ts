import { Component, OnInit  } from '@angular/core';
import {ReunionService} from '../../service/reunion.service' ;
import { Reunion } from '../../Model/reunion';
import { FormsModule, ReactiveFormsModule , FormGroup, FormControl}  from '@angular/forms';


@Component({
  selector: 'app-rensignement-update',
  templateUrl: './rensignement-update.component.html',
  styleUrls: ['./rensignement-update.component.css']
})
export class RensignementUpdateComponent implements OnInit {


constructor( private reunionservice: ReunionService) {}
 r: Reunion[] = new Array();
reunion : Reunion ;


ngOnInit(){

  this.getAll () ;
 }

 private getAll() {

  this.reunionservice.getAll().subscribe(data => {
this.r=data ;
      console.log(this.r);
    }, ex => {
      console.log(ex);
    });

  }

  delete(id: number) {

    this.reunionservice.delete(id).subscribe(data => {
      if (data.success) {} else { }

    }, ex => {

     console.log(ex);
    });
  }







}






