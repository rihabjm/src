import { Component, OnInit } from '@angular/core';
import { MembreService } from '../../Service/membre.service';
import { Membre } from '../../Model/membre';
@Component({
  selector: 'app-membre-list',
  templateUrl: './membre-list.component.html',
  styleUrls: ['./membre-list.component.css']
})
export class MembreListComponent implements OnInit {
 m: Membre[] = new Array();
  constructor(private membreservice: MembreService) { }

  ngOnInit() {
  }

 private local() {

  this.membreservice.getLocal().subscribe(data => {

     this.m= data ;
      console.log(data);
    }, ex => {
      console.log(ex);
    });

}

 private regional() {

  this.membreservice.getRegioanl().subscribe(data => {

     this.m= data ;
      console.log(data);
    }, ex => {
      console.log(ex);
    });

}

 private national() {

  this.membreservice.getNational().subscribe(data => {

     this.m= data ;
      console.log(data);
    }, ex => {
      console.log(ex);
    });

}

}
