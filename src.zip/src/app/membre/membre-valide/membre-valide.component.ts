import { Component, OnInit } from '@angular/core';
import { MembreService } from '../../Service/membre.service';
import { Membre } from '../../Model/membre';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
  selector: 'app-membre-valide',
  templateUrl: './membre-valide.component.html',
  styleUrls: ['./membre-valide.component.css']
})
export class MembreValideComponent implements OnInit {
  m: Membre[] = new Array();
membre : Membre ;
  constructor(private membreservice: MembreService) { }

  ngOnInit() {this.getAll();
  }

private getAll() {

  this.membreservice.getAll().subscribe(data => {

     this.m= data ;
      console.log(data);
    }, ex => {
      console.log(ex);
    });
}

  private valide(membre : Membre) {
    this.membreservice.valide(membre).subscribe( data => {

     if (data.success) {} else {}
    }, ex => {console.log(ex);
    });
  }
}
