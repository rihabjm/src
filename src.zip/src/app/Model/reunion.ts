export class Reunion {

  id_reu:number ;
  Date_reun: String;
   type_reun :String ;
 pv_reunion : String ;
heu_deb_reu: String ;
	 heu_fin_reu :String ;
objectif  :String;
valide :boolean;
}
