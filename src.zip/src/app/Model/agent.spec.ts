import { Agent } from './agent';

describe('Agent', () => {
  it('should create an instance', () => {
    expect(new Agent()).toBeTruthy();
  });
});
