export class Agent {
type_agent : String ;
}

